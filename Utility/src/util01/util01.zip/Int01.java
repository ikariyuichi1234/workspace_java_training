package util01;

@SuppressWarnings("resource")
public class Int01 {
	public static String Name;
	public static void main(String[] args) {

	}
	
	public static int getMin (Integer[] numData) {
		int min = numData[0];
		for (int i = 0; i < numData.length; i++) {
			if (min > numData[i]) {
				min = numData[i];
			}
		}
		return min;
	}
	public static int getMax (Integer[] numData) {
		int max = numData[0];
		for (int i = 0; i < numData.length; i++) {
			if (max > numData[i]) {
				max = numData[i];
			}
		}
		return max;
	}

}
