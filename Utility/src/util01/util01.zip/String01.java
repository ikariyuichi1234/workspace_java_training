package util01;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
@SuppressWarnings("resource")
public class String01 {
	
	public static int num;
	public static String str;
	public static String Name;
	public static String[] array = new String[5];
	public static Integer[] data = new Integer[5];
	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
//　Stringのint化、nextLine統一用
		num = Integer.parseInt(sc.nextLine());
		
//　Stringの配列化
		array = str.split(" ");
		
//　配列のString化
		str = String.join(" ", array);
		
//	配列のArrayList化
		List<String> aList = Arrays.asList(array);
		
//	ArrayListの配列化
		String[] array = aList.toArray(new String[aList.size()]);
		
	}
//　intのString化
	public static String IntCatchStrReturn (int n) {
		Integer num = Integer.valueOf(n);
	    return num.toString();
	}
	
//	int配列のString配列化
	public static String[] arrayTrance (int[] data) {
		String[] array = new String[data.length];
		for (int i = 0; i < data.length; i++) {
			Integer num = Integer.valueOf(data[i]);
			array[i] = num.toString();
		}
		return array;
	}
	
//	String配列のInteger配列化
	public static Integer[] dataTrance (String[] array) {
		Integer[] data = new Integer[array.length];
		for (int i = 0; i < array.length; i++) {
			data[i] = Integer.parseInt(array[i]);
		}
		return data;
	}
	
	
//　文字の置換
	public static String replaceStr (String str) {
		String reStr01 = str.replaceAll("[A-z]", "");
		String reStr02 = reStr01.replaceAll("1", "A");
		return reStr02.replaceAll("2", "B");
	}
	
//	Nameが空文字の場合false、そうでなければtrueを返す
	public static boolean check01 () {
		if (Name.length() == 0) {
			return false;
		} else {
			return true;
		}
	}

//	Nameに0~9の数字が含まれる場合false、そうでなければtrueを返す
	public static boolean check02 () {
		if (Name.matches(".*([0-9]).*")) {
			return false;
		} else {
			return true;
		}
	}
	
//	Nameに@が含まれる場合false、そうでなければtrueを返す
	public static boolean check03 () {
		if (Name.contains("@")) {
			return false;
		} else {
			return true;
		}
	}

}
